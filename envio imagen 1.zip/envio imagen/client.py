import camera
import network
import time
import socket
import struct

try:
    print('Tomando una foto')
    camera.init(0, format=camera.JPEG, fb_location=camera.PSRAM)
    buffer = camera.capture()
    
    # Asegúrate de que buffer contenga datos válidos
    if buffer is not None:
        print(len(buffer))
        filepath = "captured_image2.jpg"
        
        # Abre el archivo en modo binario
        with open(filepath, "wb") as file:
            file.write(buffer)
    
    # Configuración de la conexión a la red
    station = network.WLAN(network.STA_IF)
    station.active(True)
    station.connect("vivo Y33s", "cuy00123")
    
    ticks1 = time.ticks_ms()
    
    while not station.isconnected():
        ticks2 = time.ticks_ms()
        if time.ticks_diff(ticks1, ticks2) % 10000 == 0:
            print("Conectando...")
    
    print('Conexión exitosa')
    print(station.ifconfig())
    
    # Conectar al servidor manualmente
    host = '192.168.26.28'  # Dirección IP del servidor
    port = 6190  # Puerto del servidor
    
    # Crear un socket
    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Conectar al servidor
    conn.connect((host, port))
    
    print("Conectado al servidor.")
    
   
    conn.sendall(buffer)  # Enviar el contenido del archivo
    
    conn.close()
    print("Archivo enviado.")

except Exception as e:
    print(e)

finally:
    print('Finalizando cámara')
    
    camera.deinit()


#cristianCuy
#sergioRodriguez