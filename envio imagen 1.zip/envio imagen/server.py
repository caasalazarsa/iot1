import socket
import struct
import os

def receive_file_size(sck: socket.socket):
    fmt = "<Q"
    expected_bytes = struct.calcsize(fmt)
    received_bytes = 0
    stream = bytes()
    while received_bytes < expected_bytes:
        chunk = sck.recv(expected_bytes - received_bytes)
        stream += chunk
        received_bytes += len(chunk)
    filesize = struct.unpack(fmt, stream)[0]
    return filesize

def receive_file(sck: socket.socket, directory):
    # Asegúrate de que el directorio existe
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Obtener tamaño del archivo
    #filesize = receive_file_size(sck)
    
    # Guardar el archivo en la carpeta especificada
    filename = os.path.join(directory, "imagen-recibida.jpg")
    with open(filename, "wb") as f:
        received_bytes = 0
        while True:
            chunk = sck.recv(1024)
            if chunk:
                f.write(chunk)
                received_bytes += len(chunk)
            else:
                break

with socket.create_server(("192.168.26.28", 6190)) as server:
    print("Esperando al cliente...")
    conn, address = server.accept()
    print(f"{address[0]}:{address[1]} conectado.")
    print("Recibiendo archivo...")
    receive_file(conn, "C:\\Users\\ASUS\\OneDrive\\Desktop\\IOT\\envio imagen")  # Especifica aquí tu carpeta deseada
    print("Archivo recibido.")

print("Conexión cerrada.")
#cristianCuy
#sergioRodriguez